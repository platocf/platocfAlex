``tornado.tcpclient`` --- `.IOStream` connection factory
========================================================

.. automodule:: tornado.tcpclient
   :members:
